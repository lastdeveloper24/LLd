import Config.LoggerConfig;
import Level.LogLevel;
import Loggers.Logger;



public class LogDriver {
    LoggerFactory loggerFactory = new LoggerFactory();
    String pattern = "yyyy-MM-dd HH:mm:ss";


    void Info(String comment){
        Logger logger = loggerFactory.getLogger(LogLevel.INFO);
        String additionalDate = LoggerConfig.getAdditionalDate(pattern);
        comment = LogLevel.INFO+" "+"["+additionalDate+"]"+" "+comment;
        logger.log("namespace1", LogLevel.INFO, comment);
    }

    void Error(String comment){
        Logger logger = loggerFactory.getLogger(LogLevel.ERROR);
        String additionalDate = LoggerConfig.getAdditionalDate(pattern);
        comment = LogLevel.ERROR+" "+"["+additionalDate+"]"+" "+comment;
        logger.log("namespace1", LogLevel.ERROR, comment);
    }

    void Fatal(String comment){
        Logger logger = loggerFactory.getLogger(LogLevel.FATAL);
        String additionalDate = LoggerConfig.getAdditionalDate(pattern);
        comment = LogLevel.FATAL+" "+"["+additionalDate+"]"+" "+comment;
        logger.log("namespace1",LogLevel.FATAL, comment);
    }

    void Warn(String comment){
        Logger logger = loggerFactory.getLogger(LogLevel.WARN);
        String additionalDate = LoggerConfig.getAdditionalDate(pattern);
        comment = LogLevel.WARN+" "+"["+additionalDate+"]"+" "+comment;
        logger.log("namespace1", LogLevel.WARN, comment);
    }

    void Debug(String comment){
        Logger logger = loggerFactory.getLogger(LogLevel.DEBUG);
        String additionalDate = LoggerConfig.getAdditionalDate(pattern);
        comment = LogLevel.DEBUG+" "+"["+additionalDate+"]"+" "+comment;
        logger.log("namespace1", LogLevel.DEBUG, comment);
    }
}


