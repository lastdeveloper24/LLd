package Level;

public enum LogLevel {
    INFO,
    WARN,
    FATAL,
    ERROR,
    DEBUG

}
