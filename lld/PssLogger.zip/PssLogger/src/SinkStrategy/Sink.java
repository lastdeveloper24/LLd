package SinkStrategy;

public interface Sink {
    public void write(String content);
}
